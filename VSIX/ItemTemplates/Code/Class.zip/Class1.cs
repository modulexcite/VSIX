﻿using Bridge;
using Bridge.Html5;
using System;

namespace $rootnamespace$
{
    class $safeitemname$
    {
    }
}
